#ifndef FILE_UTIL_H
#define FILE_UTIL_H

extern const char * const SYSTEM_DMI_PATH_LINUX;

char* getFileContent(const char* filepath);

#endif /* FILE_UTIL_H */
